using System;

namespace DatabaseAndModuleCalculations 
{
    public class DBAndModuleCalculations 
    {
        public int CalculateSelfStudyHrs(int credits, int numberOfWeeks, int hrsPerWeek)
        {
            int result;
            result = ((credits * 10) / numberOfWeeks) - hrsPerWeek;
            return result;
        }

        public void AddHoursToDatabase()
        {

        }

        public string RecordTimeSpent(int hrsSpent, DateTime studyDate)
        {
            string text = $"{hrsSpent.ToString()} : {studyDate.ToString()}";
            return text;

        }

        public void UpdateWeeklyHours(int hrsSpent)
        {

        }

        public Boolean CheckLoginDetails(string username, string password)
        {
            Boolean flag;
            if (true)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            return flag;
        }
    }
    
}
