﻿namespace ClassLibrary1
{
    public class Class1
    {
        public Class1()
        {

        }

        public string GetMyName()
        {
            return "Sharif";
        }
    }
}